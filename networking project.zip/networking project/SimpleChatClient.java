package cscorner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleChatClient {
    JTextArea incoming;
    JTextField outgoing;
    BufferedReader reader;
    PrintWriter writer;
    Socket sock;
    private String ip = "127.0.0.1";

    public static void main(String[] args) {
        SimpleChatClient client = new SimpleChatClient();
        client.go();
    }

    public void go() {
        JFrame frame = new JFrame("Simple Chat Client");
        JPanel mainPanel = new JPanel();
        incoming = new JTextArea(15, 50);
        incoming.setLineWrap(true);
        incoming.setWrapStyleWord(false);
        incoming.setEditable(false);
        JScrollPane qScroller = new JScrollPane(incoming);
        qScroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        qScroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        outgoing = new JTextField(20);
        
        // Create the send button with Discord-like color
        JButton sendButton = new JButton("Send");
        sendButton.setBackground(new Color(114, 137, 218)); // Discord blue color
        sendButton.setForeground(Color.WHITE); // Text color
        sendButton.setFocusPainted(false); // Remove focus border
        
        sendButton.addActionListener(new SendButtonListener());
        mainPanel.add(qScroller);
        mainPanel.add(outgoing);
        mainPanel.add(sendButton);

        // Footer to display IP address
        JLabel footerLabel = new JLabel("IP Address: " + ip);
        footerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.getContentPane().add(BorderLayout.SOUTH, footerLabel);

        setUpNetworking();

        Thread readerThread = new Thread(new IncomingReader());
        readerThread.start();

        frame.getContentPane().add(BorderLayout.CENTER, mainPanel);
        frame.setSize(800, 500);
        frame.setVisible(true);
    }   // close go

    private void setUpNetworking() {
        try {
            sock = new Socket(ip, 5000);
            InputStreamReader streamReader = new InputStreamReader(sock.getInputStream());
            reader = new BufferedReader(streamReader);
            writer = new PrintWriter(sock.getOutputStream());
            System.out.println("Networking established!");
        } catch(IOException ex) {
            ex.printStackTrace();
        }
    } // close setUpNetworking

    public class SendButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            try {
                writer.println(outgoing.getText());
                writer.flush();
            } catch(Exception ex) {
                ex.printStackTrace();
            }
            outgoing.setText("");
            outgoing.requestFocus();
        }
    }  // close inner class

    public class IncomingReader implements Runnable {
        public void run() {
            String message;
            try {
                while((message = reader.readLine()) != null) {
                    // Get the current time
                    String time = getTime();
                    // Format the incoming message with time
                    String formattedMessage = time + " " + message;
                    System.out.println("read (" + ip + ") " + formattedMessage);
                    incoming.append(formattedMessage + "\n");
                }
            } catch(Exception ex) {
                ex.printStackTrace();
            }
        }

        // Method to get current time
        private String getTime() {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss a"); // Format: 12-hour clock
            return sdf.format(new Date());
        }
    }
}
